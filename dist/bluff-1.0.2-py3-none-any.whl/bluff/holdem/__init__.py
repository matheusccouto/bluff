""" Bluff's Texas Hold'em sub-module. """

import bluff


class Poker(bluff.Poker):
    """ Chinese Poker. """

    _N_STARTING_CARDS: int = 2
